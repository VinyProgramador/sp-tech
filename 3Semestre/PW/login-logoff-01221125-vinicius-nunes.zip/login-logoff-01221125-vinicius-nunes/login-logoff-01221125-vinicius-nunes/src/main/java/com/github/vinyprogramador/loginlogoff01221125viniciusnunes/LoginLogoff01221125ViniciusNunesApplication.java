package com.github.vinyprogramador.loginlogoff01221125viniciusnunes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginLogoff01221125ViniciusNunesApplication {

	public static void main(String[] args) {
		SpringApplication.run(
				LoginLogoff01221125ViniciusNunesApplication.class, args);
	}

}
