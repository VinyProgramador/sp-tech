package com.github.vinyprogramador.loginlogoff01221125viniciusnunes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginLogoff01221125ViniciusNunesApplicationTests {

	@Test
	void contextLoads() {
	}

}
