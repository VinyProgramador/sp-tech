package com.github.vinyprogramador.comicsapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
//Nome: Vinicius A Nunes
//RA: 01221125
@SpringBootApplication
public class ComicsApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ComicsApiApplication.class, args);
	}

}
